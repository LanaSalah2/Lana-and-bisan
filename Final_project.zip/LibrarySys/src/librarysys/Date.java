/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysys;

import java.util.Calendar;

/**
 *
 * @author user
 */
public class Date {
    private int day;
    private int mounth;
    private int year;

    public Date() {
    }
public java.sql.Date toSqlDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, this.year);
        calendar.set(Calendar.MONTH, this.mounth - 1); // 
        calendar.set(Calendar.DAY_OF_MONTH, this.day);
        return new java.sql.Date(calendar.getTimeInMillis());
    }
    public Date(int day, int mounth, int year) {
        this.day = day;
        this.mounth = mounth;
        this.year = year;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMounth() {
        return mounth;
    }

    public void setMounth(int mounth) {
        this.mounth = mounth;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    public String getInfo()
    {
        return "year-" + this.year + "mounth-" + this.mounth + "day-" + this.day;
    }
}
