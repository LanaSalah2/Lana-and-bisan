/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysys;

/**
 *
 * @author user
 */
public class Person {
    private int id;
    private String name;
    private Date d1;
    private int address;

    public Person()
    {
        
    }
    public Person(int id,String name,Date d1,int address) {
        this.id = id;
        this.address = address;
        this.name = name;
        this.d1 = d1;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getD1() {
        return d1;
    }

    public void setD1(Date d1) {
        this.d1 = d1;
    }

    public int getAddress() {
        return address;
    }

    public void setAddress(int address) {
        this.address = address;
    }
    public String getInfo()
    {
        return "id:" + this.id + "name:" + this.name + d1.getInfo();
    }
    
}
