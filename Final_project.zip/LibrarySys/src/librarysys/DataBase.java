/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysys;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class DataBase {

    private PreparedStatement statement;
    private final Connection conn;

    public DataBase() throws SQLException, ClassNotFoundException {
        this.conn = DriverManager.getConnection("jdbc:mysql://localhost/LibrarySystem", "root", "");
    }

    public void insertStudent(int id, String Name, String Major, Date d1) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        String sql = "INSERT INTO Studant(Id,name,major,Date) VALUES (?, ?, ?,?);";
        this.statement = conn.prepareStatement(sql);
        statement.setInt(1, id);
        statement.setString(2, Name);
        statement.setString(3, Major);
        java.sql.Date sqlDate;
        sqlDate = d1.toSqlDate();
        statement.setDate(4, sqlDate);
        statement.executeUpdate();
        if (statement != null) {
            statement.close();
        }

    }

    public void insertBook(String Name, String a1, int no, String Type, boolean Loan) throws ClassNotFoundException, SQLException {

        Class.forName("com.mysql.jdbc.Driver");
        String sql = "INSERT INTO Book(Name,Auther,No,Type,Loan) VALUES (?, ?, ?,?,?);"; // جملة استعلام
        this.statement = conn.prepareStatement(sql);  // تحويل جملة الاستعلام لجملـة مفهـومة
        statement.setString(1, Name);
        statement.setString(2, a1);
        statement.setInt(3, no);
        statement.setString(4, Type);
        statement.setBoolean(5, Loan);
        statement.executeUpdate(); // ضلك حدث بقاعـدة البيانـات
        if (statement != null) { // 
            // 
            statement.close(); // سكر
        }

    }

    public ArrayList<Object[]> returnStudent() throws SQLException, ClassNotFoundException {

        Class.forName("com.mysql.jdbc.Driver");
        String query = "SELECT * FROM studant;";
        statement = conn.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery(query);
        ArrayList<Object[]> ob = new ArrayList<>();
        int c = 0;
        while (resultSet.next()) {
            // new Object []{Name.getText(),Id.getText(),Major.getText(),date2}
            Object[] r = new Object[]{resultSet.getString("Name"), resultSet.getInt("Id"), resultSet.getString("Major"), resultSet.getDate("Date")};
            ob.add(r);
            // m is an array !!

        }
        return ob;
    }

    /*     public int returnRowCount () throws SQLException, ClassNotFoundException
      {
      Class.forName("com.mysql.jdbc.Driver");
      String query = "Select * FROM studant";
      statement = conn.prepareStatement(query);
      ResultSet resultSet = statement.executeQuery(query);
      int c = 0;
      while(resultSet.next())
      c++;
      return c;
      }*/
    public ArrayList<Studant> allStudant() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        String query = "SELECT * FROM studant;";
        statement = conn.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery(query);
        ArrayList<Studant> st = new ArrayList<>();

        while (resultSet.next()) {
            java.sql.Date sqlDate = resultSet.getDate("Date");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(sqlDate);
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            int month = calendar.get(Calendar.MONTH) + 1; // يناير = 0
            int year = calendar.get(Calendar.YEAR);
            Date customDate = new Date(day, month, year);
            st.add(new Studant(resultSet.getInt("Id"), resultSet.getString("Name"), customDate, 0, resultSet.getString("Major")));
        }
        return st; // How I connect the date with the data base
    }

    public ArrayList<Object[]> returnBook() throws SQLException, ClassNotFoundException {

        Class.forName("com.mysql.jdbc.Driver");
        String query = "SELECT * FROM book;"; // كل الأعمدة الي موجودة . 
        statement = conn.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery(query); // كل البيانات الموجـودة  فيهـا  وخزنها في االريسالت سيت 
        ArrayList<Object[]> ob = new ArrayList<>();
        int c = 0;
        while (resultSet.next()) { // مجموعة من النتائج مرتبة بناءاً على الأعمـدة ، طول م في نتيجة ، سوي كذا 
            
            // new Object []{Name.getText(),Id.getText(),Major.getText(),date2}
            Object[] r = new Object[]{resultSet.getString("Name"), resultSet.getString("Auther"), resultSet.getInt("No"), resultSet.getString("Type"), resultSet.getBoolean("Loan")};
            ob.add(r);
            // m is an array !!

        }
        return ob;
    }

    /*     public int returnRow1Count () throws SQLException, ClassNotFoundException
      {
      Class.forName("com.mysql.jdbc.Driver");
      String query = "Select * FROM book";
      statement = conn.prepareStatement(query);
      ResultSet resultSet = statement.executeQuery(query);
      int c = 0;
      while(resultSet.next())
      c++;
      return c;
      }*/
    public ArrayList<Book> allBook() throws SQLException, ClassNotFoundException {
         Class.forName("com.mysql.jdbc.Driver");
        String query = "SELECT * FROM book;";
        statement = conn.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery(query);
        ArrayList<Book> st = new ArrayList<>();
        while (resultSet.next())
        {
            st.add(new Book (resultSet.getString("Name"),resultSet.getString("Auther"),resultSet.getInt("No"),resultSet.getString("Type"),resultSet.getBoolean("Loan")));
        }
        return st;
    }
}
