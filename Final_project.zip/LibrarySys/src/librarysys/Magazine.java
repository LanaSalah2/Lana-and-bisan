/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysys;

/**
 *
 * @author user
 */
public class Magazine extends Book {
private Date release_date;
private int issue_No;
    public Magazine(String tittle,Author a1,int no,Date d1,String gen,String edtion,Date release_date ,int issue_No ) {
        super(tittle,a1,no,d1,gen,edtion);
        this.issue_No = issue_No;
        this.release_date = release_date;
    }
    public Date getRelease_date() {
        return release_date;
    }

    public void setRelease_date(Date release_date) {
        this.release_date = release_date;
    }

    public int getIssue_No() {
        return issue_No;
    }

    public void setIssue_No(int issue_No) {
        this.issue_No = issue_No;
    }
    
    @Override
    public String getInfo()
{
    return issue_No + release_date.getInfo() + super.getInfo();
}
}
