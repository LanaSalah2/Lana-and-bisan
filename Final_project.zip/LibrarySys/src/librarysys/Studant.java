/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysys;

/**
 *
 * @author user
 */
public class Studant extends Person {
   private int NumOfbook;
   private Book [] book;
   private String major;
   private Date theDateOfBorrow;
   public Studant() {
    }
    public Studant(int id,String name,Date d1,int address,String m) {
       super(id,name,d1,address);
        major = m;
    } 
    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    @Override
    public int getId() {
        return super.getId(); //To change body of generated methods, choose Tools | Templates.
    }

    public Book[] getBook() {
        return book;
    }

    public void setBook(Book[] book) {
        this.book = book;
    }

    /**
     *
     * @return
     */
    @Override
    public String getInfo()
    {
        return "major:" + this.major + super.getInfo();
    } 
    public void setTheDateOfBorrow(Date m)
    {
        this.theDateOfBorrow = m;
    }
    public Date getTheDateOfBorrow()
    {
        return this.theDateOfBorrow;
    }

    int getNumOfbook() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setNumOfbook(int NumOfbook) {
        this.NumOfbook = NumOfbook;
    }
    
}
