/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysys;

/**
 *
 * @author user
 */
public class Author extends Person {

    public Author(int id,String name,Date d1,int address) {
        super(id,name,d1,address);
    }
   public Author ()
   {
      super.setName(null); 
   }

    @Override
    public void setName(String name) {
        super.setName(name); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getName() {
        return super.getName(); //To change body of generated methods, choose Tools | Templates.
    }
    
     @Override
    public String getInfo() {
        return super.getInfo(); 
}
}
