/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysys;

/**
 *
 * @author user
 */
public class Book implements Display {
  private  String tittle;
  private  Author a1;
  private  int no;
  private  Date d1;
  private  String gen;
  private String edtion;
  private boolean inLoan;
  private String tybe;
    public Book() {
    }
  

    public Book( String tittle,Author a1,int no,Date d1,String gen,String edtion) {
    this.tittle = tittle;
    this.a1 = a1;
    this.no = no;
    this.d1 = d1;
    this.gen = gen;
    this.edtion = edtion;
        
    }
    public Book (String tittle,String name,int no,String tybe,boolean inLoan)
    {
        this.a1 = new Author ();
        this.tittle = tittle;
        this.a1.setName(name);
        this.no = no;
        this.tybe = tybe;
        this.inLoan = inLoan;
    }


     public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public Author getA1() {
        return a1;
    }

    public void setA1(Author a1) {
        this.a1 = a1;
    }

  
    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public Date getD1() {
        return d1;
    }

    public void setD1(Date d1) {
        this.d1 = d1;
    }

    public String getGen() {
        return gen;
    }

    public void setGen(String gen) {
        this.gen = gen;
    }

    public String getEdtion() {
        return edtion;
    }

    public void setEdtion(String edtion) {
        this.edtion = edtion;
    }
    public void setinLoan(boolean s)
    {
        inLoan = s;
    }    
    public boolean getinLoan()
    {
        return inLoan;
    }
  @Override
    public String getInfo()
    {
        return "tittle:" + this.tittle + "author name:" + a1.getName() + "No:" + this.no + d1.getInfo() + "Gen:" + this.gen
                + "edtion:" + this.edtion;
    }

  @Override
    public boolean inLoan()
    {
       return false; 
    }

 
}
